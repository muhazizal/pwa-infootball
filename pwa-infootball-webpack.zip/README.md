# pwa-infootball

PWA Footbal Theme

# Install

npm install

# Run server

npm run serve

# Run build

npm run build
